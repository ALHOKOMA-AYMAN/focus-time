package com.focustime.study

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.RingtoneManager
import android.content.Context

class TimerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private var remainingWhenPaused = 0L
    private var running = false
    private var done = false

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            val left = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            remainingWhenPaused = left
            publish(left, true, false)
            updateNotification(left)
            if (left <= 0L) {
                running = false; done = true
                publish(0L, false, true)
                updateNotification(0L)
                alertUser()
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            } else handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val requested = intent.getLongExtra(EXTRA_DURATION, 0L)
                if (requested > 0L) remainingWhenPaused = requested
                if (remainingWhenPaused <= 0L) remainingWhenPaused = 25L * 60_000L
                endAt = SystemClock.elapsedRealtime() + remainingWhenPaused
                running = true; done = false
                startForeground(NOTIFICATION_ID, buildNotification(remainingWhenPaused))
                handler.removeCallbacks(ticker); handler.post(ticker)
            }
            ACTION_PAUSE -> {
                if (running) remainingWhenPaused = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
                running = false; handler.removeCallbacks(ticker)
                publish(remainingWhenPaused, false, false)
                updateNotification(remainingWhenPaused)
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
            ACTION_RESET -> {
                running = false; done = false; handler.removeCallbacks(ticker)
                remainingWhenPaused = 25L * 60_000L
                publish(remainingWhenPaused, false, false)
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
            ACTION_SET -> {
                running = false; done = false; handler.removeCallbacks(ticker)
                remainingWhenPaused = intent.getLongExtra(EXTRA_DURATION, 25L * 60_000L)
                publish(remainingWhenPaused, false, false)
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
            ACTION_SYNC -> {
                if (running) publish((endAt-SystemClock.elapsedRealtime()).coerceAtLeast(0L), true, false)
                else stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun publish(left: Long, active: Boolean, finished: Boolean) {
        sendBroadcast(Intent(ACTION_TICK).setPackage(packageName)
            .putExtra(EXTRA_REMAINING, left)
            .putExtra(EXTRA_RUNNING, active)
            .putExtra(EXTRA_DONE, finished))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "مؤقت المذاكرة", NotificationManager.IMPORTANCE_LOW)
            channel.description = "إشعار مستمر أثناء جلسة التركيز"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(left: Long): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val mins = (left + 59_999L) / 60_000L
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Focus Time — جلسة مذاكرة")
            .setContentText("متبقٍ: ${mins} دقيقة")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun updateNotification(left: Long) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(left))
    }

    private fun alertUser() {
        try {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator.vibrate(700)
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play()
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacks(ticker); super.onDestroy() }

    companion object {
        const val ACTION_TICK = "com.focustime.study.TICK"
        const val ACTION_START = "START"
        const val ACTION_PAUSE = "PAUSE"
        const val ACTION_RESET = "RESET"
        const val ACTION_SET = "SET"
        const val ACTION_SYNC = "SYNC"
        const val EXTRA_DURATION = "duration"
        const val EXTRA_REMAINING = "remaining"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_DONE = "done"
        private const val CHANNEL_ID = "study_timer"
        private const val NOTIFICATION_ID = 71
    }
}
