package com.focustime.study

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT
import android.content.Context.INPUT_METHOD_SERVICE
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var ring: TimerRing
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var customButton: Button
    private var selectedMinutes = 25
    private var remainingMs = 25L * 60_000L
    private var running = false

    private val updates = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TimerService.ACTION_TICK) return
            remainingMs = intent.getLongExtra(TimerService.EXTRA_REMAINING, remainingMs)
            running = intent.getBooleanExtra(TimerService.EXTRA_RUNNING, false)
            val done = intent.getBooleanExtra(TimerService.EXTRA_DONE, false)
            render()
            if (done) {
                status.text = "أحسنت! انتهت جلسة المذاكرة 🎉"
                startButton.text = "ابدأ من جديد"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        render()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        val filter = IntentFilter(TimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(updates, filter)
        startService(Intent(this, TimerService).setAction(TimerService.ACTION_SYNC))
    }

    override fun onPause() {
        try { unregisterReceiver(updates) } catch (_: Exception) {}
        super.onPause()
    }

    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(22), dp(24), dp(22))
            setBackgroundColor(Color.rgb(10, 17, 31))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val brand = label("FOCUS TIME", 13, Color.rgb(133, 161, 194), true).apply {
            letterSpacing = .22f
        }
        root.addView(brand, lp(WRAP, dp(28)))
        root.addView(label("وقت المذاكرة", 20, Color.WHITE, true), lp(WRAP, dp(42)))

        ring = TimerRing(this).apply { setTime(remainingMs, selectedMinutes * 60_000L) }
        root.addView(ring, LinearLayout.LayoutParams(dp(290), dp(290)).apply {
            gravity = Gravity.CENTER
            topMargin = dp(8); bottomMargin = dp(12)
        })

        status = label("جاهز للتركيز؟", 14, Color.rgb(158, 174, 197), false)
        root.addView(status, lp(WRAP, dp(35)))

        val presets = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        listOf(25, 45, 60).forEach { mins ->
            val b = button("$mins دقيقة", false)
            b.setOnClickListener { setMinutes(mins) }
            presets.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginStart = dp(4); marginEnd = dp(4)
            })
        }
        root.addView(presets, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(8); bottomMargin = dp(16)
        })

        customButton = button("مدة مخصصة", false)
        customButton.setOnClickListener { showCustomDuration() }
        root.addView(customButton, LinearLayout.LayoutParams(MATCH, dp(48)).apply {
            bottomMargin = dp(12)
        })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        startButton = button("ابدأ المذاكرة", true)
        startButton.setOnClickListener { toggleTimer() }
        val reset = button("إعادة ضبط", false)
        reset.setOnClickListener { remainingMs = selectedMinutes * 60_000L; send(TimerService.ACTION_SET, remainingMs); status.text = "تمت إعادة ضبط المؤقت"; render() }
        actions.addView(startButton, LinearLayout.LayoutParams(0, dp(54), 1.3f).apply {
            marginEnd = dp(6)
        })
        actions.addView(reset, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
            marginStart = dp(6)
        })
        root.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(4)
        })
        root.addView(label("كل دقيقة تقرّبك من هدفك.", 13, Color.rgb(113, 132, 159), false),
            LinearLayout.LayoutParams(WRAP, dp(40)).apply { gravity = Gravity.CENTER; topMargin = dp(16) })
        setContentView(root)
    }

    private fun toggleTimer() {
        if (running) send(TimerService.ACTION_PAUSE)
        else {
            if (remainingMs <= 0L) remainingMs = selectedMinutes * 60_000L
            send(TimerService.ACTION_START, remainingMs)
        }
    }

    private fun setMinutes(minutes: Int) {
        selectedMinutes = minutes.coerceIn(1, 600)
        remainingMs = selectedMinutes * 60_000L
        send(TimerService.ACTION_SET, remainingMs)
        status.text = "تم ضبط الوقت"
        render()
    }

    private fun showCustomDuration() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(selectedMinutes.toString())
            textSize = 20f
            gravity = Gravity.CENTER
            hint = "عدد الدقائق (1–600)"
        }
        AlertDialog.Builder(this)
            .setTitle("مدة المذاكرة بالدقائق")
            .setView(input)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("تطبيق") { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n == null || n !in 1..600) {
                    Toast.makeText(this, "أدخل رقماً من 1 إلى 600", Toast.LENGTH_SHORT).show()
                } else setMinutes(n)
            }.show()
    }

    private fun send(action: String, duration: Long = 0L) {
        val i = Intent(this, TimerService).setAction(action)
        if (duration > 0) i.putExtra(TimerService.EXTRA_DURATION, duration)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun render() {
        ring.setTime(remainingMs, selectedMinutes * 60_000L)
        startButton.text = when {
            running -> "إيقاف مؤقت"
            remainingMs < selectedMinutes * 60_000L && remainingMs > 0 -> "استئناف"
            remainingMs <= 0 -> "ابدأ من جديد"
            else -> "ابدأ المذاكرة"
        }
        if (!running && remainingMs > 0 && remainingMs == selectedMinutes * 60_000L)
            status.text = "جاهز للتركيز؟"
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, primary: Boolean) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setTextColor(if (primary) Color.rgb(8, 19, 32) else Color.WHITE)
        background = GradientDrawable().apply {
            cornerRadius = dp(15).toFloat()
            setColor(if (primary) Color.rgb(117, 224, 190) else Color.rgb(27, 40, 60))
            if (!primary) setStroke(dp(1), Color.rgb(52, 69, 94))
        }
        stateListAnimator = null
        minimumHeight = dp(46)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    companion object { private const val MATCH = -1; private const val WRAP = -2 }
}

private class TimerRing(context: Context) : View(context) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(34, 49, 70); style = Paint.Style.STROKE; strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(117, 224, 190); style = Paint.Style.STROKE; strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 65f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val caption = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(145, 166, 194); textAlign = Paint.Align.CENTER; textSize = 13f
        letterSpacing = .12f
    }
    private var remaining = 1500L
    private var total = 1500L

    fun setTime(left: Long, all: Long) {
        remaining = left.coerceAtLeast(0)
        total = all.coerceAtLeast(1)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f
        val radius = side * .43f
        val rect = RectF(cx-radius, cy-radius, cx+radius, cy+radius)
        canvas.drawCircle(cx, cy, radius, track)
        val sweep = 360f * (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
        canvas.drawArc(rect, -90f, sweep, false, arc)
        val seconds = (remaining + 999) / 1000
        val text = String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
        canvas.drawText(text, cx, cy + timePaint.textSize * .34f, timePaint)
        canvas.drawText("دقيقة تصنع فرقاً", cx, cy + 48f, caption)
    }
}
